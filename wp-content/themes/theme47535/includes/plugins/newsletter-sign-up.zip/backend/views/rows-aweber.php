<tr valign="top">
                        <th scope="row">Aweber list name</th>
                        <td><input size="25%" type="text" name="nsu_mailinglist[aweber_list_name]" value="<?php if (isset($opts['aweber_list_name']))
                        echo $opts['aweber_list_name']; ?>" /></td>
                    </tr>